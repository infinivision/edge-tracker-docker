## KCF tracker
#### compile
`mkdir build`\
`cd build`\
`cmake ..`\
`make -j <nproc>`

#### run
`./export 32 64 70 80 90 100`\
`./kcf <video> <start frame>`

#include <iostream>
#include "time_utils.h"

int main(int argc, char* argv[]) {
    std::cout << get_current_time() << std::endl;
}
